import streamlit as st
import pandas as pd
import numpy as np
from utils.data_processor import DataProcessor
from components.vigilancia_tab import VigilanciaTab
from components.control_larvario_tab import ControlLarvarioTab
from components.cerco_tab import CercoTab
from components.inspector_tab import InspectorTab

# Page configuration
st.set_page_config(
    page_title="Sistema de Vigilancia Epidemiológica",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Configure file upload size (200MB)
st.session_state.max_upload_size = 200 * 1024 * 1024  # 200MB

# Initialize session state
if 'data' not in st.session_state:
    st.session_state.data = None
if 'data_processor' not in st.session_state:
    st.session_state.data_processor = None

def main():
    # Theme toggle in sidebar
    st.sidebar.markdown("### ⚙️ Configuración")
    
    # Theme selector
    theme_option = st.sidebar.selectbox(
        "🎨 Tema",
        ["Claro", "Oscuro"],
        help="Selecciona el tema de la aplicación"
    )
    
    # Apply theme CSS
    if theme_option == "Oscuro":
        st.markdown("""
        <style>
            .stApp {
                background-color: #0e1117;
                color: #fafafa;
            }
            .stSidebar {
                background-color: #262730;
            }
            .stTabs [data-baseweb="tab-list"] {
                background-color: #262730;
            }
            .stTabs [data-baseweb="tab"] {
                background-color: #262730;
                color: #fafafa;
            }
            .stTabs [aria-selected="true"] {
                background-color: #0e1117;
                color: #fafafa;
            }
            .stDataFrame {
                background-color: #262730;
            }
            .stMetric {
                background-color: #262730;
                color: #fafafa;
            }
            div[data-testid="metric-container"] {
                background-color: #262730;
                border: 1px solid #4f4f4f;
                padding: 5px;
                border-radius: 5px;
            }
        </style>
        """, unsafe_allow_html=True)
    
    st.title("📊 Sistema de Vigilancia Epidemiológica")
    st.markdown("---")
    
    # Sidebar for file upload
    with st.sidebar:
        st.markdown("---")
        st.header("📁 Cargar Datos")
        
        # File size info
        st.info("📋 **Requisitos del archivo:**\n"
                "- Formato: CSV (UTF-8)\n"
                "- Columnas: 91 campos\n"
                "- Tamaño máximo: 200MB\n"
                "- Registros: Hasta 150,000+")
        
        uploaded_file = st.file_uploader(
            "Seleccione o arrastre el archivo CSV",
            type=['csv'],
            help="Archivo CSV con datos de inspección epidemiológica"
        )
        
        if uploaded_file is not None:
            # Show file info
            file_size = uploaded_file.size / (1024 * 1024)  # MB
            st.info(f"📁 **{uploaded_file.name}**\n"
                   f"Tamaño: {file_size:.1f} MB")
            
            if file_size > 200:
                st.error("⚠️ El archivo excede el límite de 200MB")
                return
                
            try:
                with st.spinner("🔄 Procesando archivo... Esto puede tomar unos minutos para archivos grandes."):
                    # Load data with optimizations for large files
                    data = pd.read_csv(
                        uploaded_file, 
                        encoding='utf-8',
                        low_memory=False
                    )
                    st.session_state.data_processor = DataProcessor(data)
                    st.session_state.data = data
                    
                st.success(f"✅ Archivo cargado exitosamente!")
                st.metric("📈 Registros", f"{len(data):,}")
                st.metric("📋 Columnas", f"{len(data.columns)}")
                
                # Show data types summary
                with st.expander("📊 Resumen de Datos"):
                    activity_types = data['tipoActividadInspeccion'].value_counts()
                    st.write("**Tipos de Actividad:**")
                    for activity, count in activity_types.items():
                        st.write(f"- {activity}: {count:,} registros")
                
            except Exception as e:
                st.error(f"❌ Error al cargar el archivo: {str(e)}")
                st.info("💡 **Posibles soluciones:**\n"
                       "- Verifique que el archivo sea CSV válido\n"
                       "- Asegúrese de que esté codificado en UTF-8\n"
                       "- Verifique que tenga las 91 columnas requeridas")
                return
    
    # Main content area
    if st.session_state.data is not None:
        # Create tabs
        tab1, tab2, tab3, tab4 = st.tabs(["🔍 Vigilancia", "🦟 Control Larvario", "🔒 Cerco", "👤 Inspectores"])
        
        with tab1:
            vigilancia_tab = VigilanciaTab(st.session_state.data_processor)
            vigilancia_tab.render()
        
        with tab2:
            control_larvario_tab = ControlLarvarioTab(st.session_state.data_processor)
            control_larvario_tab.render()
        
        with tab3:
            cerco_tab = CercoTab(st.session_state.data_processor)
            cerco_tab.render()
        
        with tab4:
            from utils.calculations import EpidemiologicalCalculations
            calculations = EpidemiologicalCalculations(st.session_state.data_processor)
            inspector_tab = InspectorTab(st.session_state.data_processor, calculations)
            inspector_tab.render()
    else:
        # Welcome screen
        st.markdown("""
        ## 👋 Bienvenido al Sistema de Vigilancia Epidemiológica
        
        Este sistema está diseñado para analizar y visualizar datos de inspecciones epidemiológicas.
        
        ### 📋 Características principales:
        - **Procesamiento de datos masivos**: Maneja más de 150,000 registros
        - **Filtros dinámicos**: Búsqueda y filtrado por múltiples criterios
        - **Cálculos especializados**: Índice Aédico y estadísticas de recipientes
        - **Visualizaciones interactivas**: Dashboards con gráficos dinámicos
        - **Tres módulos de análisis**: Vigilancia, Control Larvario y Cerco
        
        ### 🚀 Para comenzar:
        1. Cargue su archivo CSV usando el panel lateral
        2. Seleccione la pestaña de análisis deseada
        3. Configure los filtros según sus necesidades
        4. Explore los resultados en tiempo real
        
        ---
        **📁 Por favor, cargue un archivo CSV para comenzar el análisis.**
        """)

if __name__ == "__main__":
    main()
