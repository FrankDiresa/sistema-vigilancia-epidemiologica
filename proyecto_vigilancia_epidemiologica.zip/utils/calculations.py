import pandas as pd
import numpy as np

class EpidemiologicalCalculations:
    def __init__(self, data_processor):
        self.data_processor = data_processor
        # Updated health facilities data with correct house counts (complete list)
        self.health_facilities = {
            5060: {'name': 'LA LIBERTAD', 'total_houses': 136},
            5044: {'name': 'GUSTAVO LANATTA LUJAN', 'total_houses': 4282},
            7276: {'name': 'LA PRIMAVERA', 'total_houses': 1822},
            7435: {'name': 'MESONES MURO', 'total_houses': 426},
            7006: {'name': 'SAN FRANCISCO', 'total_houses': 188},
            5126: {'name': 'MIRAFLORES', 'total_houses': 206},
            5135: {'name': 'VISTA ALEGRE', 'total_houses': 41},
            5136: {'name': 'LA VICTORIA', 'total_houses': 486},
            5137: {'name': 'PUEBLO LIBRE', 'total_houses': 50},
            7225: {'name': 'MORROPON', 'total_houses': 90},
            7285: {'name': 'SAN LUIS', 'total_houses': 1874},
            5095: {'name': 'SAN JUAN DE LA LIBERTAD', 'total_houses': 456},
            5096: {'name': 'JOSE OLAYA', 'total_houses': 280},
            7258: {'name': 'SANTA ISABEL', 'total_houses': 138},
            7259: {'name': 'LA UNION', 'total_houses': 100},
            5066: {'name': 'EL MILAGRO', 'total_houses': 505},
            1720: {'name': 'SAN RAFAEL', 'total_houses': 804},
            1744: {'name': 'LA VICTORIA', 'total_houses': 7191},
            1659: {'name': 'PROGRESO', 'total_houses': 9674},
            1660: {'name': 'LA UNION', 'total_houses': 4576},
            1661: {'name': 'SAN PEDRO', 'total_houses': 11249},
            1662: {'name': 'VICTOR RAUL', 'total_houses': 2309},
            1663: {'name': 'TUPAC AMARU', 'total_houses': 1799},
            1664: {'name': 'LA ESPERANZA', 'total_houses': 2004},
            1715: {'name': 'SAN JACINTO', 'total_houses': 10725},
            1706: {'name': 'VILLA MARIA', 'total_houses': 5568},
            1681: {'name': 'ALTO PERU', 'total_houses': 374},
            2664: {'name': 'BELLAVISTA', 'total_houses': 3738},
            8828: {'name': 'SAN MARTIN', 'total_houses': 2213},
            2570: {'name': 'SANTA ROSA', 'total_houses': 350},
            1345: {'name': 'SAN JOSE', 'total_houses': 90},
            1368: {'name': 'SANTA ROSA', 'total_houses': 153},
            23961: {'name': 'MIRAFLORES', 'total_houses': 365},
            3760: {'name': 'LECHEMAYO', 'total_houses': 716},
            3749: {'name': 'PALMAPAMPA', 'total_houses': 1924},
            3764: {'name': 'SANTA ROSA', 'total_houses': 3711},
            4230: {'name': 'SAN AGUSTIN', 'total_houses': 460},
            25858: {'name': 'NUEVO HORIZONTE', 'total_houses': 1327},
            4261: {'name': 'SANTA ROSA', 'total_houses': 579},
            4274: {'name': 'CHIRINOS', 'total_houses': 813},
            7411: {'name': 'BUENOS AIRES', 'total_houses': 198},
            10966: {'name': 'VISTA FLORIDA', 'total_houses': 62},
            10965: {'name': 'LA UNION', 'total_houses': 275},
            4267: {'name': 'SAN IGNACIO', 'total_houses': 6329},
            4270: {'name': 'NUEVA ESPERANZA', 'total_houses': 330},
            4272: {'name': 'SAN MARTIN', 'total_houses': 50},
            4273: {'name': 'SAN ANTONIO', 'total_houses': 143},
            6229: {'name': 'JOSE OLAYA', 'total_houses': 3391},
            6230: {'name': 'ACAPULCO', 'total_houses': 4412},
            6233: {'name': 'JUAN PABLO II', 'total_houses': 1855},
            6234: {'name': 'SANTA ROSA', 'total_houses': 1728},
            6235: {'name': 'MIGUEL GRAU', 'total_houses': 795},
            6246: {'name': 'EL ALAMO', 'total_houses': 4059},
            2355: {'name': 'LA QUEBRADA', 'total_houses': 689},
            2303: {'name': 'SANTA ROSA', 'total_houses': 56},
            2442: {'name': 'PUERTO RICO', 'total_houses': 99},
            8283: {'name': 'PUEBLO LIBRE', 'total_houses': 185},
            2460: {'name': 'SANTA MARIA', 'total_houses': 456},
            7113: {'name': 'NATIVIDAD', 'total_houses': 746},
            32211: {'name': 'NUEVO PROGRESO', 'total_houses': 1916},
            2468: {'name': 'SAN MARTIN', 'total_houses': 60},
            760: {'name': 'LA ESPERANZA', 'total_houses': 5637},
            775: {'name': 'ACOMAYO', 'total_houses': 1152},
            948: {'name': 'SAN ISIDRO', 'total_houses': 476},
            19199: {'name': 'SAN AGUSTIN', 'total_houses': 227},
            954: {'name': 'PUEBLO NUEVO', 'total_houses': 2865},
            956: {'name': 'LAS MERCEDES', 'total_houses': 272},
            958: {'name': 'TUPAC AMARU', 'total_houses': 183},
            27772: {'name': 'NUEVO PROGRESO', 'total_houses': 200},
            29172: {'name': 'LA PRIMAVERA', 'total_houses': 109},
            936: {'name': 'NARANJILLO', 'total_houses': 2653},
            940: {'name': 'MARONA', 'total_houses': 259},
            949: {'name': 'RICARDO PALMA', 'total_houses': 363},
            974: {'name': 'LAS PALMAS', 'total_houses': 509},
            18569: {'name': 'CONSUELO', 'total_houses': 416},
            28088: {'name': 'LA LOMA', 'total_houses': 220},
            942: {'name': 'HUASCAR', 'total_houses': 154},
            922: {'name': 'SEÑOR DE LOS MILAGROS', 'total_houses': 131},
            11071: {'name': 'EL DORADO', 'total_houses': 233},
            3442: {'name': 'SAN AGUSTIN', 'total_houses': 2579},
            7015: {'name': 'CRUZ BLANCA', 'total_houses': 2110},
            5193: {'name': 'C.S. EL PARCO', 'total_houses': 150}
        }
    
    def calculate_aedic_index(self, filtered_data):
        """
        Calculate Aedic Index for each health facility
        Formula: (Positive Houses / Inspected Houses) * 100
        """
        results = []
        
        # Group by health facility code
        grouped = filtered_data.groupby('cod_renipress')
        
        for renipress_code, group in grouped:
            # Count inspected houses (atencion_vivienda_indicador == 1)
            inspected_houses = len(group[group['atencion_vivienda_indicador'] == 1])
            
            # Count positive houses (viv_positiva == 1 and atencion_vivienda_indicador == 1)
            positive_houses = len(group[
                (group['viv_positiva'] == 1) & 
                (group['atencion_vivienda_indicador'] == 1)
            ])
            
            # Calculate Aedic Index
            aedic_index = (positive_houses / inspected_houses * 100) if inspected_houses > 0 else 0
            
            # Get health facility info
            facility_info = self.health_facilities.get(renipress_code, {})
            facility_name = group['localidad_eess'].iloc[0] if len(group) > 0 else "Desconocido"
            
            results.append({
                'cod_renipress': renipress_code,
                'localidad_eess': facility_name,
                'total_houses': facility_info.get('total_houses', 0),
                'inspected_houses': inspected_houses,
                'positive_houses': positive_houses,
                'aedic_index': round(aedic_index, 2)
            })
        
        return pd.DataFrame(results)
    
    def calculate_container_statistics(self, filtered_data):
        """Calculate statistics for all container types"""
        containers = self.data_processor.get_container_columns()
        status_labels = self.data_processor.get_container_status_labels()
        
        results = []
        
        for container_type, columns in containers.items():
            container_stats = {'container_type': container_type}
            
            # Group by status suffix
            for suffix, label in status_labels.items():
                matching_columns = [col for col in columns if col.endswith(suffix)]
                if matching_columns:
                    total = filtered_data[matching_columns].sum().sum()
                    container_stats[label] = total
            
            results.append(container_stats)
        
        return pd.DataFrame(results)
    
    def calculate_larvicide_consumption(self, filtered_data):
        """Calculate total and per-facility larvicide consumption"""
        if 'consumo_larvicida' not in filtered_data.columns:
            return pd.DataFrame(), 0
        
        # Total consumption
        total_consumption = filtered_data['consumo_larvicida'].sum()
        
        # Consumption by health facility
        facility_consumption = filtered_data.groupby(['cod_renipress', 'localidad_eess'])['consumo_larvicida'].sum().reset_index()
        facility_consumption = facility_consumption.sort_values('consumo_larvicida', ascending=False)
        
        return facility_consumption, total_consumption
    
    def calculate_inspection_summary(self, filtered_data):
        """Calculate summary statistics for inspections"""
        if 'atencion_vivienda_indicador' not in filtered_data.columns:
            return {}
        
        # Count by inspection status
        status_counts = filtered_data['atencion_vivienda_indicador'].value_counts()
        
        status_mapping = {
            1: "Vivienda Inspeccionada",
            2: "Vivienda Cerrada", 
            3: "Vivienda Renuente",
            4: "Vivienda Deshabitada"
        }
        
        summary = {}
        for status_code, status_name in status_mapping.items():
            summary[status_name] = status_counts.get(status_code, 0)
        
        # Calculate positive houses percentage
        total_inspected = summary.get("Vivienda Inspeccionada", 0)
        positive_houses = len(filtered_data[
            (filtered_data['viv_positiva'] == 1) & 
            (filtered_data['atencion_vivienda_indicador'] == 1)
        ])
        
        summary['Viviendas Positivas'] = positive_houses
        summary['Porcentaje Positividad'] = (positive_houses / total_inspected * 100) if total_inspected > 0 else 0
        
        return summary
    
    def calculate_monthly_trends(self, filtered_data):
        """Calculate monthly trends for key metrics"""
        if 'fecha_inspeccion' not in filtered_data.columns:
            return pd.DataFrame()
        
        # Create monthly aggregation
        filtered_data['month_year'] = filtered_data['fecha_inspeccion'].dt.to_period('M')
        
        monthly_stats = filtered_data.groupby('month_year').agg({
            'atencion_vivienda_indicador': lambda x: (x == 1).sum(),  # Inspected houses
            'viv_positiva': lambda x: ((x == 1) & (filtered_data.loc[x.index, 'atencion_vivienda_indicador'] == 1)).sum(),  # Positive houses
            'consumo_larvicida': 'sum'
        }).reset_index()
        
        monthly_stats['month_year_str'] = monthly_stats['month_year'].astype(str)
        monthly_stats['aedic_index'] = (monthly_stats['viv_positiva'] / monthly_stats['atencion_vivienda_indicador'] * 100).fillna(0)
        
        return monthly_stats

    def calculate_coverage_percentages(self, filtered_data):
        """Calculate coverage percentages for each health facility"""
        results = []
        
        # Group by health facility code
        grouped = filtered_data.groupby('cod_renipress')
        
        for renipress_code, group in grouped:
            # Get facility info
            facility_info = self.health_facilities.get(renipress_code, {})
            facility_name = group['localidad_eess'].iloc[0] if len(group) > 0 else "Desconocido"
            total_houses = facility_info.get('total_houses', 0)
            
            # Count by house status
            inspected = len(group[group['atencion_vivienda_indicador'] == 1])
            closed = len(group[group['atencion_vivienda_indicador'] == 2])
            reluctant = len(group[group['atencion_vivienda_indicador'] == 3])
            uninhabited = len(group[group['atencion_vivienda_indicador'] == 4])
            
            # Calculate non-intervened houses
            total_intervened = inspected + closed + reluctant + uninhabited
            non_intervened = max(0, total_houses - total_intervened)
            
            # Calculate percentages
            def calc_percentage(value, total):
                return (value / total * 100) if total > 0 else 0
            
            results.append({
                'cod_renipress': renipress_code,
                'localidad_eess': facility_name,
                'total_houses': total_houses,
                'inspected_count': inspected,
                'closed_count': closed,
                'reluctant_count': reluctant,
                'uninhabited_count': uninhabited,
                'non_intervened_count': non_intervened,
                'inspected_percentage': calc_percentage(inspected, total_houses),
                'closed_percentage': calc_percentage(closed, total_houses),
                'reluctant_percentage': calc_percentage(reluctant, total_houses),
                'uninhabited_percentage': calc_percentage(uninhabited, total_houses),
                'non_intervened_percentage': calc_percentage(non_intervened, total_houses),
                'total_coverage': calc_percentage(total_intervened, total_houses)
            })
        
        return pd.DataFrame(results)

    def calculate_febril_cases(self, filtered_data):
        """Calculate febril cases by health facility"""
        if 'febriles' not in filtered_data.columns:
            return pd.DataFrame(), 0
        
        # Total febril cases
        total_febriles = filtered_data['febriles'].sum()
        
        # Febril cases by health facility
        facility_febriles = filtered_data.groupby(['cod_renipress', 'localidad_eess'])['febriles'].sum().reset_index()
        facility_febriles = facility_febriles.sort_values('febriles', ascending=False)
        
        return facility_febriles, total_febriles
