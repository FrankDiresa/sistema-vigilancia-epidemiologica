import streamlit as st
import pandas as pd
from components.filters import FilterComponent
from utils.calculations import EpidemiologicalCalculations
from utils.visualizations import VisualizationHelper

class VigilanciaTab:
    def __init__(self, data_processor):
        self.data_processor = data_processor
        self.filter_component = FilterComponent(data_processor)
        self.calculations = EpidemiologicalCalculations(data_processor)
        self.viz_helper = VisualizationHelper()
    
    def render(self):
        st.header("🔍 Módulo de Vigilancia")
        st.markdown("Análisis de datos de vigilancia epidemiológica")
        
        # Render filters
        filters = self.filter_component.render_filters('vigilancia')
        
        # Get filtered data
        filtered_data = self.data_processor.get_filtered_data('vigilancia', filters)
        
        # Apply date range filter if present
        if 'date_range' in filters:
            filtered_data = self.filter_component.apply_date_filter(filtered_data, filters['date_range'])
        
        # Show data summary
        st.markdown("---")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("📊 Total Registros", f"{len(filtered_data):,}")
        
        with col2:
            inspected = len(filtered_data[filtered_data['atencion_vivienda_indicador'] == 1])
            st.metric("🏠 Viviendas Inspeccionadas", f"{inspected:,}")
        
        with col3:
            positive = len(filtered_data[
                (filtered_data['viv_positiva'] == 1) & 
                (filtered_data['atencion_vivienda_indicador'] == 1)
            ])
            st.metric("⚠️ Viviendas Positivas", f"{positive:,}")
        
        with col4:
            if inspected > 0:
                percentage = (positive / inspected * 100)
                st.metric("📈 % Positividad", f"{percentage:.2f}%")
            else:
                st.metric("📈 % Positividad", "0.00%")
        
        if len(filtered_data) == 0:
            st.warning("⚠️ No se encontraron datos con los filtros seleccionados.")
            return
        
        # Create tabs for different visualizations
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Índice Aédico", 
            "📦 Recipientes", 
            "🧪 Larvicida", 
            "📈 Tendencias",
            "🗺️ Mapa"
        ])
        
        with tab1:
            self.render_aedic_index_tab(filtered_data)
        
        with tab2:
            self.render_containers_tab(filtered_data)
        
        with tab3:
            self.render_larvicide_tab(filtered_data)
        
        with tab4:
            self.render_trends_tab(filtered_data)
        
        with tab5:
            self.render_map_tab(filtered_data)
    
    def render_aedic_index_tab(self, filtered_data):
        st.subheader("📊 Índice Aédico por Establecimiento de Salud")
        st.markdown("**Fórmula:** (Viviendas Positivas / Viviendas Inspeccionadas) × 100")
        
        # Calculate Aedic Index
        aedic_data = self.calculations.calculate_aedic_index(filtered_data)
        
        if not aedic_data.empty:
            # Display chart
            fig = self.viz_helper.create_aedic_index_chart(aedic_data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Display table with Spanish column names
            st.subheader("📋 Detalle por Establecimiento")
            st.dataframe(
                aedic_data.sort_values('aedic_index', ascending=False),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código',
                    'localidad_eess': 'Establecimiento de Salud',
                    'total_houses': 'Viv. Totales',
                    'inspected_houses': 'Viv. Inspeccionadas',
                    'positive_houses': 'Viv. Positivas',
                    'aedic_index': 'Ind. Aédico'
                }
            )
            
            # Summary statistics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("🏥 Establecimientos", len(aedic_data))
            with col2:
                avg_index = aedic_data['aedic_index'].mean()
                st.metric("📊 Índice Promedio", f"{avg_index:.2f}%")
            with col3:
                max_index = aedic_data['aedic_index'].max()
                st.metric("⚠️ Índice Máximo", f"{max_index:.2f}%")
        else:
            st.info("No hay datos suficientes para calcular el Índice Aédico.")
    
    def render_containers_tab(self, filtered_data):
        st.subheader("📦 Estadísticas de Recipientes")
        
        # Calculate container statistics
        container_data = self.calculations.calculate_container_statistics(filtered_data)
        
        if not container_data.empty:
            # Display chart
            fig = self.viz_helper.create_container_statistics_chart(container_data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Display table with Spanish column names
            st.subheader("📋 Detalle por Tipo de Recipiente")
            st.dataframe(
                container_data, 
                use_container_width=True, 
                hide_index=True,
                column_config={
                    'container_type': 'Tipo de Recipiente'
                }
            )
            
            # Container status legend
            st.subheader("📖 Leyenda de Estados")
            status_labels = self.data_processor.get_container_status_labels()
            
            cols = st.columns(len(status_labels))
            for i, (suffix, label) in enumerate(status_labels.items()):
                with cols[i]:
                    st.info(f"**{suffix}:** {label}")
        else:
            st.info("No hay datos de recipientes disponibles.")
    
    def render_larvicide_tab(self, filtered_data):
        st.subheader("🧪 Consumo de Larvicida")
        
        # Calculate larvicide consumption
        facility_consumption, total_consumption = self.calculations.calculate_larvicide_consumption(filtered_data)
        
        col1, col2 = st.columns([1, 3])
        
        with col1:
            st.metric("💊 Consumo Total", f"{total_consumption:.2f}")
            
            if not facility_consumption.empty:
                avg_consumption = facility_consumption['consumo_larvicida'].mean()
                st.metric("📊 Consumo Promedio", f"{avg_consumption:.2f}")
                
                max_consumption = facility_consumption['consumo_larvicida'].max()
                st.metric("📈 Consumo Máximo", f"{max_consumption:.2f}")
        
        with col2:
            if not facility_consumption.empty:
                # Display chart
                fig = self.viz_helper.create_larvicide_consumption_chart(facility_consumption)
                st.plotly_chart(fig, use_container_width=True)
        
        # Display table with Spanish column names
        if not facility_consumption.empty:
            st.subheader("📋 Consumo por Establecimiento")
            st.dataframe(
                facility_consumption.round(2),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código',
                    'localidad_eess': 'Establecimiento de Salud',
                    'consumo_larvicida': 'Consumo de Larvicida'
                }
            )
        else:
            st.info("No hay datos de consumo de larvicida disponibles.")
    
    def render_trends_tab(self, filtered_data):
        st.subheader("📈 Tendencias Mensuales")
        
        # Calculate monthly trends
        monthly_data = self.calculations.calculate_monthly_trends(filtered_data)
        
        if not monthly_data.empty:
            # Display chart
            fig = self.viz_helper.create_monthly_trends_chart(monthly_data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Display table
            st.subheader("📋 Datos Mensuales")
            display_data = monthly_data.copy()
            display_data['aedic_index'] = display_data['aedic_index'].round(2)
            display_data['consumo_larvicida'] = display_data['consumo_larvicida'].round(2)
            
            st.dataframe(
                display_data[['month_year_str', 'atencion_vivienda_indicador', 
                            'viv_positiva', 'aedic_index', 'consumo_larvicida']],
                use_container_width=True,
                hide_index=True,
                column_config={
                    'month_year_str': 'Mes/Año',
                    'atencion_vivienda_indicador': 'Viviendas Inspeccionadas',
                    'viv_positiva': 'Viviendas Positivas',
                    'aedic_index': 'Índice Aédico (%)',
                    'consumo_larvicida': 'Consumo Larvicida'
                }
            )
        else:
            st.info("No hay datos suficientes para mostrar tendencias mensuales.")
    
    def render_map_tab(self, filtered_data):
        st.subheader("🗺️ Distribución Geográfica")
        
        # Display map
        fig = self.viz_helper.create_map_visualization(filtered_data)
        st.plotly_chart(fig, use_container_width=True)
        
        # Summary by coordinates
        if 'georeferencia_X' in filtered_data.columns and 'georeferencia_Y' in filtered_data.columns:
            valid_coords = filtered_data[
                (filtered_data['georeferencia_X'].notna()) & 
                (filtered_data['georeferencia_Y'].notna())
            ]
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("📍 Puntos Georeferenciados", len(valid_coords))
            with col2:
                positive_coords = len(valid_coords[valid_coords['viv_positiva'] == 1])
                st.metric("⚠️ Puntos Positivos", positive_coords)
            with col3:
                if len(valid_coords) > 0:
                    percentage = (positive_coords / len(valid_coords) * 100)
                    st.metric("📈 % Positividad Geográfica", f"{percentage:.2f}%")
        else:
            st.info("No hay datos de georeferenciación disponibles.")
