import streamlit as st
import pandas as pd
from components.filters import FilterComponent
from utils.calculations import EpidemiologicalCalculations
from utils.visualizations import VisualizationHelper

class CercoTab:
    def __init__(self, data_processor):
        self.data_processor = data_processor
        self.filter_component = FilterComponent(data_processor)
        self.calculations = EpidemiologicalCalculations(data_processor)
        self.viz_helper = VisualizationHelper()
    
    def render(self):
        st.header("🔒 Módulo de Cerco")
        st.markdown("Análisis de datos de actividades de cerco epidemiológico")
        
        # Render filters
        filters = self.filter_component.render_filters('cerco')
        
        # Get filtered data for cerco activity
        filtered_data = self.data_processor.get_filtered_data('cerco', filters)
        
        # Apply date range filter if present
        if 'date_range' in filters:
            filtered_data = self.filter_component.apply_date_filter(filtered_data, filters['date_range'])
        
        # Show data summary
        st.markdown("---")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("📊 Total Registros", f"{len(filtered_data):,}")
        
        with col2:
            # Calculate houses under cerco intervention
            houses_cerco = len(filtered_data[filtered_data['atencion_vivienda_indicador'].isin([1, 2, 3, 4])])
            st.metric("🏠 Viviendas en Cerco", f"{houses_cerco:,}")
        
        with col3:
            # Calculate positive detections in cerco
            positive_cerco = len(filtered_data[
                (filtered_data['viv_positiva'] == 1) & 
                (filtered_data['atencion_vivienda_indicador'] == 1)
            ])
            st.metric("⚠️ Detecciones Positivas", f"{positive_cerco:,}")
        
        with col4:
            # Calculate cerco effectiveness
            if houses_cerco > 0:
                effectiveness = ((houses_cerco - positive_cerco) / houses_cerco * 100)
                st.metric("🎯 Efectividad", f"{effectiveness:.1f}%")
            else:
                st.metric("🎯 Efectividad", "0.0%")
        
        if len(filtered_data) == 0:
            st.warning("⚠️ No se encontraron datos con los filtros seleccionados.")
            return
        
        # Create tabs for different visualizations
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Cobertura de Viviendas",
            "📦 Análisis de Recipientes",
            "🧪 Consumo Larvicida",
            "🤒 Casos Febriles",
            "📈 Tendencias"
        ])
        
        with tab1:
            self.render_coverage_analysis_tab(filtered_data)
        
        with tab2:
            self.render_container_analysis_tab(filtered_data)
        
        with tab3:
            self.render_larvicide_analysis_tab(filtered_data)
        
        with tab4:
            self.render_febril_cases_tab(filtered_data)
        
        with tab5:
            self.render_trends_tab(filtered_data)
    
    def render_coverage_analysis_tab(self, filtered_data):
        st.subheader("📊 Análisis de Cobertura de Viviendas - Cerco")
        
        # Calculate coverage percentages
        coverage_data = self.calculations.calculate_coverage_percentages(filtered_data)
        
        if not coverage_data.empty:
            # Display summary metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                avg_coverage = coverage_data['total_coverage'].mean()
                st.metric("📈 Cobertura Promedio", f"{avg_coverage:.1f}%")
            
            with col2:
                total_inspected = coverage_data['inspected_count'].sum()
                st.metric("🏠 Total Inspeccionadas", f"{total_inspected:,}")
            
            with col3:
                total_closed = coverage_data['closed_count'].sum()
                st.metric("🚪 Total Cerradas", f"{total_closed:,}")
            
            with col4:
                total_reluctant = coverage_data['reluctant_count'].sum()
                st.metric("🚫 Total Renuentes", f"{total_reluctant:,}")
            
            # Coverage visualization
            import plotly.express as px
            
            # Create stacked bar chart for coverage
            coverage_melted = coverage_data.melt(
                id_vars=['localidad_eess'],
                value_vars=['inspected_percentage', 'closed_percentage', 'reluctant_percentage', 
                           'uninhabited_percentage', 'non_intervened_percentage'],
                var_name='status_type',
                value_name='percentage'
            )
            
            # Rename categories for better display
            status_mapping = {
                'inspected_percentage': 'Inspeccionadas',
                'closed_percentage': 'Cerradas',
                'reluctant_percentage': 'Renuentes',
                'uninhabited_percentage': 'Deshabitadas',
                'non_intervened_percentage': 'No Intervenidas'
            }
            coverage_melted['status_type'] = coverage_melted['status_type'].map(status_mapping)
            
            fig = px.bar(
                coverage_melted,
                x='localidad_eess',
                y='percentage',
                color='status_type',
                title='Porcentaje de Cobertura por Establecimiento y Tipo - Cerco',
                labels={
                    'percentage': 'Porcentaje (%)',
                    'localidad_eess': 'Establecimiento de Salud',
                    'status_type': 'Tipo de Vivienda'
                }
            )
            
            fig.update_layout(
                xaxis={'tickangle': 45},
                height=600,
                barmode='stack'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Display detailed table
            st.subheader("📋 Detalle de Cobertura por Establecimiento")
            st.dataframe(
                coverage_data.round(2),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'total_houses': 'Total Viviendas',
                    'total_coverage': 'Cobertura Total (%)',
                    'inspected_percentage': 'Inspeccionadas (%)',
                    'closed_percentage': 'Cerradas (%)',
                    'reluctant_percentage': 'Renuentes (%)',
                    'uninhabited_percentage': 'Deshabitadas (%)',
                    'non_intervened_percentage': 'No Intervenidas (%)'
                }
            )
        else:
            st.info("No hay suficientes datos para calcular la cobertura.")

    def render_container_analysis_tab(self, filtered_data):
        st.subheader("📦 Análisis de Recipientes - Cerco")
        
        # Calculate container statistics
        container_data = self.calculations.calculate_container_statistics(filtered_data)
        
        if not container_data.empty:
            # Display chart
            fig = self.viz_helper.create_container_statistics_chart(container_data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Display table
            st.subheader("📋 Detalle por Tipo de Recipiente")
            st.dataframe(
                container_data, 
                use_container_width=True, 
                hide_index=True,
                column_config={
                    'container_type': 'Tipo de Recipiente'
                }
            )
            
            # Container status legend
            st.subheader("📖 Leyenda de Estados")
            status_labels = self.data_processor.get_container_status_labels()
            
            cols = st.columns(len(status_labels))
            for i, (suffix, label) in enumerate(status_labels.items()):
                with cols[i]:
                    st.info(f"**{suffix}:** {label}")
        else:
            st.info("No hay datos de recipientes disponibles.")

    def render_larvicide_analysis_tab(self, filtered_data):
        st.subheader("🧪 Análisis de Consumo de Larvicida - Cerco")
        
        # Calculate larvicide consumption
        facility_consumption, total_consumption = self.calculations.calculate_larvicide_consumption(filtered_data)
        
        col1, col2 = st.columns([1, 3])
        
        with col1:
            st.metric("💊 Consumo Total", f"{total_consumption:.2f}")
            
            if not facility_consumption.empty:
                avg_consumption = facility_consumption['consumo_larvicida'].mean()
                st.metric("📊 Consumo Promedio", f"{avg_consumption:.2f}")
                
                max_consumption = facility_consumption['consumo_larvicida'].max()
                st.metric("📈 Consumo Máximo", f"{max_consumption:.2f}")
        
        with col2:
            if not facility_consumption.empty:
                # Display chart
                fig = self.viz_helper.create_larvicide_consumption_chart(facility_consumption)
                st.plotly_chart(fig, use_container_width=True)
        
        # Display table
        if not facility_consumption.empty:
            st.subheader("📋 Consumo por Establecimiento")
            st.dataframe(
                facility_consumption.round(2),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código',
                    'localidad_eess': 'Establecimiento de Salud',
                    'consumo_larvicida': 'Consumo de Larvicida'
                }
            )
        else:
            st.info("No hay datos de consumo de larvicida disponibles.")

    def render_febril_cases_tab(self, filtered_data):
        st.subheader("🤒 Análisis de Casos Febriles - Cerco")
        
        # Calculate febril cases
        facility_febriles, total_febriles = self.calculations.calculate_febril_cases(filtered_data)
        
        col1, col2 = st.columns([1, 3])
        
        with col1:
            st.metric("🌡️ Total Casos Febriles", f"{total_febriles:,}")
            
            if not facility_febriles.empty:
                avg_febriles = facility_febriles['febriles'].mean()
                st.metric("📊 Promedio por Establecimiento", f"{avg_febriles:.1f}")
                
                max_febriles = facility_febriles['febriles'].max()
                st.metric("📈 Mayor Cantidad", f"{max_febriles:,}")
        
        with col2:
            if not facility_febriles.empty:
                # Display chart for top facilities with febril cases
                top_febriles = facility_febriles.head(15)
                
                import plotly.express as px
                fig = px.bar(
                    top_febriles,
                    x='febriles',
                    y='localidad_eess',
                    orientation='h',
                    title='Casos Febriles por Establecimiento (Top 15) - Cerco',
                    labels={
                        'febriles': 'Casos Febriles',
                        'localidad_eess': 'Establecimiento de Salud'
                    },
                    color='febriles',
                    color_continuous_scale='Reds'
                )
                
                fig.update_layout(height=500, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
        
        # Display table
        if not facility_febriles.empty:
            st.subheader("📋 Casos Febriles por Establecimiento")
            st.dataframe(
                facility_febriles,
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'febriles': 'Casos Febriles'
                }
            )
        else:
            st.info("No hay datos de casos febriles disponibles.")

    def render_trends_tab(self, filtered_data):
        st.subheader("📈 Tendencias de Cerco")
        
        # Calculate monthly trends
        monthly_data = self.calculations.calculate_monthly_trends(filtered_data)
        
        if not monthly_data.empty:
            # Display chart
            fig = self.viz_helper.create_monthly_trends_chart(monthly_data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Display table
            st.subheader("📋 Datos Mensuales")
            display_data = monthly_data.copy()
            display_data['aedic_index'] = display_data['aedic_index'].round(2)
            display_data['consumo_larvicida'] = display_data['consumo_larvicida'].round(2)
            
            st.dataframe(
                display_data[['month_year_str', 'atencion_vivienda_indicador', 
                            'viv_positiva', 'aedic_index', 'consumo_larvicida']],
                use_container_width=True,
                hide_index=True,
                column_config={
                    'month_year_str': 'Mes/Año',
                    'atencion_vivienda_indicador': 'Viviendas Inspeccionadas',
                    'viv_positiva': 'Viviendas Positivas',
                    'aedic_index': 'Índice Aédico (%)',
                    'consumo_larvicida': 'Consumo Larvicida'
                }
            )
        else:
            st.info("No hay datos suficientes para mostrar tendencias mensuales.")
    
    def render_effectiveness_analysis_tab(self, filtered_data):
        st.subheader("🎯 Análisis de Efectividad del Cerco")
        
        # Calculate effectiveness metrics by facility
        effectiveness_data = self.calculate_cerco_effectiveness(filtered_data)
        
        if not effectiveness_data.empty:
            # Display effectiveness chart
            import plotly.express as px
            
            fig = px.bar(
                effectiveness_data.sort_values('effectiveness_percentage', ascending=True),
                x='effectiveness_percentage',
                y='localidad_eess',
                orientation='h',
                title='Efectividad del Cerco por Establecimiento (%)',
                labels={
                    'effectiveness_percentage': 'Efectividad (%)',
                    'localidad_eess': 'Establecimiento de Salud'
                },
                color='effectiveness_percentage',
                color_continuous_scale='RdYlGn'
            )
            
            fig.update_layout(height=max(400, len(effectiveness_data) * 25))
            st.plotly_chart(fig, use_container_width=True)
            
            # Display effectiveness table
            st.subheader("📊 Tabla de Efectividad")
            st.dataframe(
                effectiveness_data.round(2),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'total_houses': 'Total Viviendas',
                    'positive_houses': 'Viviendas Positivas',
                    'effectiveness_percentage': 'Efectividad (%)',
                    'intervention_score': 'Score de Intervención'
                }
            )
            
            # Summary statistics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                avg_effectiveness = effectiveness_data['effectiveness_percentage'].mean()
                st.metric("📊 Efectividad Promedio", f"{avg_effectiveness:.1f}%")
            
            with col2:
                best_facility = effectiveness_data.loc[effectiveness_data['effectiveness_percentage'].idxmax(), 'localidad_eess']
                st.metric("🏆 Mejor Establecimiento", best_facility)
            
            with col3:
                total_interventions = effectiveness_data['total_houses'].sum()
                st.metric("🏠 Total Intervenciones", f"{total_interventions:,}")
        
        else:
            st.info("No hay suficientes datos para calcular la efectividad del cerco.")
    
    def render_geographic_coverage_tab(self, filtered_data):
        st.subheader("🗺️ Cobertura Geográfica del Cerco")
        
        # Geographic distribution analysis
        geographic_data = self.calculate_geographic_coverage(filtered_data)
        
        # Display map visualization
        fig = self.viz_helper.create_map_visualization(filtered_data)
        st.plotly_chart(fig, use_container_width=True)
        
        # Coverage statistics
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📊 Cobertura por Área")
            if geographic_data:
                for area, stats in geographic_data.items():
                    with st.expander(f"🏛️ {area}"):
                        st.metric("Establecimientos", stats['facilities'])
                        st.metric("Viviendas Intervenidas", stats['houses'])
                        st.metric("Efectividad", f"{stats['effectiveness']:.1f}%")
        
        with col2:
            st.subheader("🎯 Densidad de Intervención")
            
            # Calculate intervention density
            density_data = self.calculate_intervention_density(filtered_data)
            
            if not density_data.empty:
                import plotly.express as px
                
                fig = px.scatter(
                    density_data,
                    x='intervention_density',
                    y='effectiveness',
                    size='total_houses',
                    hover_data=['localidad_eess'],
                    title='Densidad vs Efectividad de Intervención',
                    labels={
                        'intervention_density': 'Densidad de Intervención',
                        'effectiveness': 'Efectividad (%)'
                    }
                )
                
                st.plotly_chart(fig, use_container_width=True)
    
    def render_cerco_indicators_tab(self, filtered_data):
        st.subheader("📈 Indicadores Específicos de Cerco")
        
        # Calculate cerco-specific indicators
        cerco_indicators = self.calculate_cerco_indicators(filtered_data)
        
        # Display key indicators
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "🔍 Tasa de Detección",
                f"{cerco_indicators.get('detection_rate', 0):.2f}%"
            )
        
        with col2:
            st.metric(
                "⚡ Tiempo Respuesta Promedio",
                f"{cerco_indicators.get('avg_response_time', 0):.1f} días"
            )
        
        with col3:
            st.metric(
                "🎯 Cobertura de Cerco",
                f"{cerco_indicators.get('coverage_rate', 0):.1f}%"
            )
        
        with col4:
            st.metric(
                "🔄 Tasa de Reintervención",
                f"{cerco_indicators.get('reintervention_rate', 0):.1f}%"
            )
        
        # Cerco performance trends
        if 'fecha_inspeccion' in filtered_data.columns:
            monthly_trends = self.calculate_cerco_monthly_trends(filtered_data)
            
            if not monthly_trends.empty:
                st.subheader("📈 Tendencias de Indicadores de Cerco")
                
                import plotly.graph_objects as go
                from plotly.subplots import make_subplots
                
                fig = make_subplots(
                    rows=2, cols=2,
                    subplot_titles=[
                        'Detecciones Mensuales',
                        'Efectividad Mensual',
                        'Cobertura Mensual',
                        'Tiempo de Respuesta'
                    ]
                )
                
                # Add traces for each indicator
                fig.add_trace(
                    go.Scatter(
                        x=monthly_trends['month_year'],
                        y=monthly_trends['detections'],
                        name='Detecciones',
                        line=dict(color='red')
                    ),
                    row=1, col=1
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=monthly_trends['month_year'],
                        y=monthly_trends['effectiveness'],
                        name='Efectividad',
                        line=dict(color='green')
                    ),
                    row=1, col=2
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=monthly_trends['month_year'],
                        y=monthly_trends['coverage'],
                        name='Cobertura',
                        line=dict(color='blue')
                    ),
                    row=2, col=1
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=monthly_trends['month_year'],
                        y=monthly_trends['response_time'],
                        name='Tiempo Respuesta',
                        line=dict(color='orange')
                    ),
                    row=2, col=2
                )
                
                fig.update_layout(height=600, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
    
    def render_recovery_tracking_tab(self, filtered_data):
        st.subheader("🔄 Seguimiento y Recuperación")
        
        # Recovery analysis
        recovery_data = self.calculate_recovery_metrics(filtered_data)
        
        if recovery_data:
            # Display recovery metrics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric(
                    "✅ Viviendas Recuperadas",
                    f"{recovery_data.get('recovered_houses', 0):,}"
                )
            
            with col2:
                st.metric(
                    "📈 Tasa de Recuperación",
                    f"{recovery_data.get('recovery_rate', 0):.1f}%"
                )
            
            with col3:
                st.metric(
                    "⏱️ Tiempo Promedio Recuperación",
                    f"{recovery_data.get('avg_recovery_time', 0):.1f} días"
                )
            
            # Recovery tracking table
            if 'recovery_details' in recovery_data:
                st.subheader("📋 Detalle de Recuperaciones")
                st.dataframe(
                    recovery_data['recovery_details'],
                    use_container_width=True,
                    hide_index=True
                )
        
        else:
            st.info("No hay datos de recuperación disponibles.")
        
        # Follow-up activities summary
        followup_summary = self.calculate_followup_summary(filtered_data)
        
        if followup_summary:
            st.subheader("📊 Resumen de Actividades de Seguimiento")
            
            # Display follow-up chart
            import plotly.express as px
            
            if 'activity_types' in followup_summary:
                fig = px.pie(
                    values=list(followup_summary['activity_types'].values()),
                    names=list(followup_summary['activity_types'].keys()),
                    title='Distribución de Actividades de Seguimiento'
                )
                
                st.plotly_chart(fig, use_container_width=True)
    
    def calculate_cerco_effectiveness(self, data):
        """Calculate cerco effectiveness by facility"""
        if data.empty:
            return pd.DataFrame()
        
        effectiveness_data = []
        
        for facility in data['localidad_eess'].unique():
            facility_data = data[data['localidad_eess'] == facility]
            
            # Get RENIPRESS code
            renipress_code = facility_data['cod_renipress'].iloc[0] if len(facility_data) > 0 else 0
            
            # Calculate metrics
            total_houses = len(facility_data[facility_data['atencion_vivienda_indicador'].isin([1, 2, 3, 4])])
            positive_houses = len(facility_data[
                (facility_data['viv_positiva'] == 1) & 
                (facility_data['atencion_vivienda_indicador'] == 1)
            ])
            
            # Calculate effectiveness (higher is better)
            effectiveness = ((total_houses - positive_houses) / total_houses * 100) if total_houses > 0 else 0
            
            # Calculate intervention score
            intervention_score = min(10, (total_houses / max(1, positive_houses)) * 2)
            
            effectiveness_data.append({
                'cod_renipress': renipress_code,
                'localidad_eess': facility,
                'total_houses': total_houses,
                'positive_houses': positive_houses,
                'effectiveness_percentage': effectiveness,
                'intervention_score': intervention_score
            })
        
        return pd.DataFrame(effectiveness_data)
    
    def calculate_geographic_coverage(self, data):
        """Calculate geographic coverage statistics"""
        coverage = {}
        
        if 'departamento_x' in data.columns:
            for dept in data['departamento_x'].unique():
                dept_data = data[data['departamento_x'] == dept]
                
                facilities = dept_data['localidad_eess'].nunique()
                houses = len(dept_data[dept_data['atencion_vivienda_indicador'].isin([1, 2, 3, 4])])
                positive = len(dept_data[
                    (dept_data['viv_positiva'] == 1) & 
                    (dept_data['atencion_vivienda_indicador'] == 1)
                ])
                
                effectiveness = ((houses - positive) / houses * 100) if houses > 0 else 0
                
                coverage[dept] = {
                    'facilities': facilities,
                    'houses': houses,
                    'effectiveness': effectiveness
                }
        
        return coverage
    
    def calculate_intervention_density(self, data):
        """Calculate intervention density metrics"""
        if data.empty:
            return pd.DataFrame()
        
        density_data = []
        
        for facility in data['localidad_eess'].unique():
            facility_data = data[data['localidad_eess'] == facility]
            
            # Calculate density (interventions per area unit - simplified)
            total_houses = len(facility_data[facility_data['atencion_vivienda_indicador'].isin([1, 2, 3, 4])])
            positive_houses = len(facility_data[
                (facility_data['viv_positiva'] == 1) & 
                (facility_data['atencion_vivienda_indicador'] == 1)
            ])
            
            # Simplified density calculation
            intervention_density = total_houses / max(1, len(facility_data.groupby('codigo_manzana')))
            effectiveness = ((total_houses - positive_houses) / total_houses * 100) if total_houses > 0 else 0
            
            density_data.append({
                'localidad_eess': facility,
                'intervention_density': intervention_density,
                'effectiveness': effectiveness,
                'total_houses': total_houses
            })
        
        return pd.DataFrame(density_data)
    
    def calculate_cerco_indicators(self, data):
        """Calculate cerco-specific indicators"""
        indicators = {}
        
        if not data.empty:
            # Detection rate
            total_inspected = len(data[data['atencion_vivienda_indicador'] == 1])
            positive_detected = len(data[
                (data['viv_positiva'] == 1) & 
                (data['atencion_vivienda_indicador'] == 1)
            ])
            
            indicators['detection_rate'] = (positive_detected / total_inspected * 100) if total_inspected > 0 else 0
            
            # Coverage rate (simplified)
            total_houses = len(data[data['atencion_vivienda_indicador'].isin([1, 2, 3, 4])])
            target_houses = len(data)  # Assuming all records are target houses
            indicators['coverage_rate'] = (total_houses / target_houses * 100) if target_houses > 0 else 0
            
            # Average response time (simplified - using days between creation and inspection)
            if 'fecha_inspeccion' in data.columns and '_createdAt_x' in data.columns:
                data_with_dates = data[
                    (data['fecha_inspeccion'].notna()) & 
                    (data['_createdAt_x'].notna())
                ]
                
                if not data_with_dates.empty:
                    response_times = (data_with_dates['fecha_inspeccion'] - data_with_dates['_createdAt_x']).dt.days
                    indicators['avg_response_time'] = response_times.mean()
                else:
                    indicators['avg_response_time'] = 0
            else:
                indicators['avg_response_time'] = 0
            
            # Reintervention rate (simplified)
            unique_addresses = data['dirección'].nunique() if 'dirección' in data.columns else 1
            total_interventions = len(data)
            indicators['reintervention_rate'] = ((total_interventions - unique_addresses) / unique_addresses * 100) if unique_addresses > 0 else 0
        
        return indicators
    
    def calculate_cerco_monthly_trends(self, data):
        """Calculate monthly trends for cerco indicators"""
        if 'fecha_inspeccion' not in data.columns:
            return pd.DataFrame()
        
        data['month_year'] = data['fecha_inspeccion'].dt.to_period('M')
        
        monthly_data = []
        
        for period in data['month_year'].unique():
            period_data = data[data['month_year'] == period]
            
            detections = len(period_data[
                (period_data['viv_positiva'] == 1) & 
                (period_data['atencion_vivienda_indicador'] == 1)
            ])
            
            total_houses = len(period_data[period_data['atencion_vivienda_indicador'].isin([1, 2, 3, 4])])
            effectiveness = ((total_houses - detections) / total_houses * 100) if total_houses > 0 else 0
            
            coverage = (total_houses / len(period_data) * 100) if len(period_data) > 0 else 0
            
            # Simplified response time calculation
            response_time = 5.0  # Placeholder value
            
            monthly_data.append({
                'month_year': str(period),
                'detections': detections,
                'effectiveness': effectiveness,
                'coverage': coverage,
                'response_time': response_time
            })
        
        return pd.DataFrame(monthly_data)
    
    def calculate_recovery_metrics(self, data):
        """Calculate recovery metrics"""
        recovery_data = {}
        
        if 'recuperada' in data.columns:
            # Count recovered houses
            recovered_houses = data['recuperada'].sum()
            total_positive = len(data[data['viv_positiva'] == 1])
            
            recovery_data['recovered_houses'] = int(recovered_houses)
            recovery_data['recovery_rate'] = (recovered_houses / total_positive * 100) if total_positive > 0 else 0
            
            # Calculate average recovery time
            if 'recuperacion_fecha' in data.columns and 'fecha_inspeccion' in data.columns:
                recovery_times_data = data[
                    (data['recuperacion_fecha'].notna()) & 
                    (data['fecha_inspeccion'].notna()) &
                    (data['recuperada'] == 1)
                ]
                
                if not recovery_times_data.empty:
                    recovery_times = (recovery_times_data['recuperacion_fecha'] - recovery_times_data['fecha_inspeccion']).dt.days
                    recovery_data['avg_recovery_time'] = recovery_times.mean()
                else:
                    recovery_data['avg_recovery_time'] = 0
            
            # Recovery details
            if recovered_houses > 0:
                recovery_details = data[data['recuperada'] == 1][
                    ['localidad_eess', 'dirección', 'fecha_inspeccion', 'recuperacion_fecha', 'recuperacion_usuario_asignado']
                ].copy()
                
                recovery_data['recovery_details'] = recovery_details
        
        return recovery_data
    
    def calculate_followup_summary(self, data):
        """Calculate follow-up activities summary"""
        summary = {}
        
        # Activity type distribution
        if 'atencion_vivienda_indicador' in data.columns:
            activity_counts = data['atencion_vivienda_indicador'].value_counts()
            
            activity_mapping = {
                1: "Inspección Completa",
                2: "Vivienda Cerrada", 
                3: "Vivienda Renuente",
                4: "Vivienda Deshabitada"
            }
            
            activity_types = {}
            for code, count in activity_counts.items():
                activity_name = activity_mapping.get(code, f"Código {code}")
                activity_types[activity_name] = count
            
            summary['activity_types'] = activity_types
        
        return summary
