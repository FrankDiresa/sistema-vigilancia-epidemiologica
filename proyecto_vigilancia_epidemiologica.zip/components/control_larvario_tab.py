import streamlit as st
import pandas as pd
from components.filters import FilterComponent
from utils.calculations import EpidemiologicalCalculations
from utils.visualizations import VisualizationHelper

class ControlLarvarioTab:
    def __init__(self, data_processor):
        self.data_processor = data_processor
        self.filter_component = FilterComponent(data_processor)
        self.calculations = EpidemiologicalCalculations(data_processor)
        self.viz_helper = VisualizationHelper()
    
    def render(self):
        st.header("🦟 Módulo de Control Larvario")
        st.markdown("Análisis de datos de control larvario")
        
        # Render filters
        filters = self.filter_component.render_filters('control larvario')
        
        # Get filtered data for control larvario activity
        filtered_data = self.data_processor.get_filtered_data('control larvario', filters)
        
        # Apply date range filter if present
        if 'date_range' in filters:
            filtered_data = self.filter_component.apply_date_filter(filtered_data, filters['date_range'])
        
        # Show data summary
        st.markdown("---")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("📊 Total Registros", f"{len(filtered_data):,}")
        
        with col2:
            total_larvicide = filtered_data['consumo_larvicida'].sum() if 'consumo_larvicida' in filtered_data.columns else 0
            st.metric("🧪 Consumo Total Larvicida", f"{total_larvicide:.2f}")
        
        with col3:
            treated_containers = self.calculate_treated_containers(filtered_data)
            st.metric("📦 Recipientes Tratados", f"{treated_containers:,}")
        
        with col4:
            facilities = filtered_data['localidad_eess'].nunique() if 'localidad_eess' in filtered_data.columns else 0
            st.metric("🏥 Establecimientos", facilities)
        
        if len(filtered_data) == 0:
            st.warning("⚠️ No se encontraron datos con los filtros seleccionados.")
            return
        
        # Create tabs for different visualizations
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Cobertura de Viviendas",
            "🧪 Análisis Larvicida", 
            "📦 Tratamiento de Recipientes", 
            "🤒 Casos Febriles",
            "📈 Tendencias"
        ])
        
        with tab1:
            self.render_coverage_analysis_tab(filtered_data)
        
        with tab2:
            self.render_larvicide_analysis_tab(filtered_data)
        
        with tab3:
            self.render_container_treatment_tab(filtered_data)
        
        with tab4:
            self.render_febril_cases_tab(filtered_data)
        
        with tab5:
            self.render_trends_tab(filtered_data)
    
    def calculate_treated_containers(self, data):
        """Calculate total number of treated containers (TQ + TF)"""
        containers = self.data_processor.get_container_columns()
        total_treated = 0
        
        for container_type, columns in containers.items():
            tq_columns = [col for col in columns if col.endswith('_TQ')]
            tf_columns = [col for col in columns if col.endswith('_TF')]
            
            for col in tq_columns + tf_columns:
                if col in data.columns:
                    total_treated += data[col].sum()
        
        return int(total_treated)
    
    def render_coverage_analysis_tab(self, filtered_data):
        st.subheader("📊 Análisis de Cobertura de Viviendas")
        
        # Calculate coverage percentages
        coverage_data = self.calculations.calculate_coverage_percentages(filtered_data)
        
        if not coverage_data.empty:
            # Display summary metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                avg_coverage = coverage_data['total_coverage'].mean()
                st.metric("📈 Cobertura Promedio", f"{avg_coverage:.1f}%")
            
            with col2:
                total_inspected = coverage_data['inspected_count'].sum()
                st.metric("🏠 Total Inspeccionadas", f"{total_inspected:,}")
            
            with col3:
                total_closed = coverage_data['closed_count'].sum()
                st.metric("🚪 Total Cerradas", f"{total_closed:,}")
            
            with col4:
                total_reluctant = coverage_data['reluctant_count'].sum()
                st.metric("🚫 Total Renuentes", f"{total_reluctant:,}")
            
            # Coverage visualization
            import plotly.express as px
            
            # Create stacked bar chart for coverage
            coverage_melted = coverage_data.melt(
                id_vars=['localidad_eess'],
                value_vars=['inspected_percentage', 'closed_percentage', 'reluctant_percentage', 
                           'uninhabited_percentage', 'non_intervened_percentage'],
                var_name='status_type',
                value_name='percentage'
            )
            
            # Rename categories for better display
            status_mapping = {
                'inspected_percentage': 'Inspeccionadas',
                'closed_percentage': 'Cerradas',
                'reluctant_percentage': 'Renuentes',
                'uninhabited_percentage': 'Deshabitadas',
                'non_intervened_percentage': 'No Intervenidas'
            }
            coverage_melted['status_type'] = coverage_melted['status_type'].map(status_mapping)
            
            fig = px.bar(
                coverage_melted,
                x='localidad_eess',
                y='percentage',
                color='status_type',
                title='Porcentaje de Cobertura por Establecimiento y Tipo',
                labels={
                    'percentage': 'Porcentaje (%)',
                    'localidad_eess': 'Establecimiento de Salud',
                    'status_type': 'Tipo de Vivienda'
                }
            )
            
            fig.update_layout(
                xaxis={'tickangle': 45},
                height=600,
                barmode='stack'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Display detailed table
            st.subheader("📋 Detalle de Cobertura por Establecimiento")
            st.dataframe(
                coverage_data.round(2),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'total_houses': 'Total Viviendas',
                    'total_coverage': 'Cobertura Total (%)',
                    'inspected_percentage': 'Inspeccionadas (%)',
                    'closed_percentage': 'Cerradas (%)',
                    'reluctant_percentage': 'Renuentes (%)',
                    'uninhabited_percentage': 'Deshabitadas (%)',
                    'non_intervened_percentage': 'No Intervenidas (%)'
                }
            )
        else:
            st.info("No hay suficientes datos para calcular la cobertura.")
    
    def render_febril_cases_tab(self, filtered_data):
        st.subheader("🤒 Análisis de Casos Febriles")
        
        # Calculate febril cases
        facility_febriles, total_febriles = self.calculations.calculate_febril_cases(filtered_data)
        
        col1, col2 = st.columns([1, 3])
        
        with col1:
            st.metric("🌡️ Total Casos Febriles", f"{total_febriles:,}")
            
            if not facility_febriles.empty:
                avg_febriles = facility_febriles['febriles'].mean()
                st.metric("📊 Promedio por Establecimiento", f"{avg_febriles:.1f}")
                
                max_febriles = facility_febriles['febriles'].max()
                st.metric("📈 Mayor Cantidad", f"{max_febriles:,}")
        
        with col2:
            if not facility_febriles.empty:
                # Display chart for top facilities with febril cases
                top_febriles = facility_febriles.head(15)
                
                import plotly.express as px
                fig = px.bar(
                    top_febriles,
                    x='febriles',
                    y='localidad_eess',
                    orientation='h',
                    title='Casos Febriles por Establecimiento (Top 15)',
                    labels={
                        'febriles': 'Casos Febriles',
                        'localidad_eess': 'Establecimiento de Salud'
                    },
                    color='febriles',
                    color_continuous_scale='Reds'
                )
                
                fig.update_layout(height=500, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
        
        # Display table
        if not facility_febriles.empty:
            st.subheader("📋 Casos Febriles por Establecimiento")
            st.dataframe(
                facility_febriles,
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'febriles': 'Casos Febriles'
                }
            )
        else:
            st.info("No hay datos de casos febriles disponibles.")
    
    def render_trends_tab(self, filtered_data):
        st.subheader("📈 Tendencias de Control Larvario")
        
        # Calculate monthly trends
        monthly_data = self.calculations.calculate_monthly_trends(filtered_data)
        
        if not monthly_data.empty:
            # Display chart
            fig = self.viz_helper.create_monthly_trends_chart(monthly_data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Display table
            st.subheader("📋 Datos Mensuales")
            display_data = monthly_data.copy()
            display_data['aedic_index'] = display_data['aedic_index'].round(2)
            display_data['consumo_larvicida'] = display_data['consumo_larvicida'].round(2)
            
            st.dataframe(
                display_data[['month_year_str', 'atencion_vivienda_indicador', 
                            'viv_positiva', 'aedic_index', 'consumo_larvicida']],
                use_container_width=True,
                hide_index=True,
                column_config={
                    'month_year_str': 'Mes/Año',
                    'atencion_vivienda_indicador': 'Viviendas Inspeccionadas',
                    'viv_positiva': 'Viviendas Positivas',
                    'aedic_index': 'Índice Aédico (%)',
                    'consumo_larvicida': 'Consumo Larvicida'
                }
            )
        else:
            st.info("No hay datos suficientes para mostrar tendencias mensuales.")
    
    def render_larvicide_analysis_tab(self, filtered_data):
        st.subheader("🧪 Análisis de Consumo de Larvicida")
        
        # Calculate larvicide consumption
        facility_consumption, total_consumption = self.calculations.calculate_larvicide_consumption(filtered_data)
        
        # Display total consumption metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("💊 Consumo Total", f"{total_consumption:.2f}")
        
        with col2:
            if not facility_consumption.empty:
                avg_consumption = facility_consumption['consumo_larvicida'].mean()
                st.metric("📊 Consumo Promedio", f"{avg_consumption:.2f}")
        
        with col3:
            if not facility_consumption.empty:
                facilities_count = len(facility_consumption)
                st.metric("🏥 Establecimientos Activos", facilities_count)
        
        if not facility_consumption.empty:
            # Display consumption chart
            fig = self.viz_helper.create_larvicide_consumption_chart(facility_consumption)
            st.plotly_chart(fig, use_container_width=True)
            
            # Efficiency analysis
            st.subheader("📈 Análisis de Eficiencia")
            
            # Calculate efficiency metrics
            efficiency_data = facility_consumption.copy()
            efficiency_data['efficiency_score'] = efficiency_data['consumo_larvicida'] / (efficiency_data['consumo_larvicida'].max() if efficiency_data['consumo_larvicida'].max() > 0 else 1)
            
            # Display efficiency table
            st.dataframe(
                efficiency_data.round(3),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'consumo_larvicida': 'Consumo Larvicida',
                    'efficiency_score': 'Score de Eficiencia'
                }
            )
        else:
            st.info("No hay datos de consumo de larvicida disponibles.")
    
    def render_container_treatment_tab(self, filtered_data):
        st.subheader("📦 Análisis de Tratamiento de Recipientes")
        
        # Calculate treatment statistics
        treatment_stats = self.calculate_treatment_statistics(filtered_data)
        
        if treatment_stats:
            # Display treatment summary
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("🧪 Tratamiento Químico", f"{treatment_stats['chemical']:,}")
            
            with col2:
                st.metric("⚙️ Tratamiento Físico", f"{treatment_stats['physical']:,}")
            
            with col3:
                total_treated = treatment_stats['chemical'] + treatment_stats['physical']
                st.metric("✅ Total Tratados", f"{total_treated:,}")
            
            with col4:
                if total_treated > 0:
                    chemical_percentage = (treatment_stats['chemical'] / total_treated * 100)
                    st.metric("🧪 % Químico", f"{chemical_percentage:.1f}%")
            
            # Container type analysis
            container_treatment_data = self.calculate_container_type_treatment(filtered_data)
            
            if not container_treatment_data.empty:
                # Create visualization
                fig = self.viz_helper.create_container_statistics_chart(container_treatment_data)
                st.plotly_chart(fig, use_container_width=True)
                
                # Display detailed table
                st.subheader("📋 Detalle por Tipo de Recipiente")
                st.dataframe(
                    container_treatment_data,
                    use_container_width=True,
                    hide_index=True
                )
        else:
            st.info("No hay datos de tratamiento de recipientes disponibles.")
    
    def render_facility_performance_tab(self, filtered_data):
        st.subheader("📈 Rendimiento por Establecimiento")
        
        # Calculate performance metrics by facility
        performance_data = self.calculate_facility_performance(filtered_data)
        
        if not performance_data.empty:
            # Display performance chart
            import plotly.express as px
            
            fig = px.bar(
                performance_data.sort_values('total_activities', ascending=True),
                x='total_activities',
                y='localidad_eess',
                orientation='h',
                title='Actividades de Control Larvario por Establecimiento',
                labels={
                    'total_activities': 'Total de Actividades',
                    'localidad_eess': 'Establecimiento de Salud'
                },
                color='efficiency_rating',
                color_continuous_scale='RdYlGn'
            )
            
            fig.update_layout(height=max(400, len(performance_data) * 25))
            st.plotly_chart(fig, use_container_width=True)
            
            # Display performance table
            st.subheader("📊 Tabla de Rendimiento")
            st.dataframe(
                performance_data.round(2),
                use_container_width=True,
                hide_index=True,
                column_config={
                    'cod_renipress': 'Código RENIPRESS',
                    'localidad_eess': 'Establecimiento',
                    'total_activities': 'Total Actividades',
                    'larvicide_used': 'Larvicida Usado',
                    'containers_treated': 'Recipientes Tratados',
                    'efficiency_rating': 'Rating de Eficiencia'
                }
            )
        else:
            st.info("No hay suficientes datos para calcular el rendimiento por establecimiento.")
    
    def render_activity_summary_tab(self, filtered_data):
        st.subheader("📊 Resumen de Actividades de Control Larvario")
        
        # General statistics
        summary_stats = self.calculate_activity_summary(filtered_data)
        
        # Display summary metrics
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📈 Métricas Generales")
            for metric, value in summary_stats.items():
                if isinstance(value, (int, float)):
                    st.metric(metric, f"{value:,.2f}" if isinstance(value, float) else f"{value:,}")
        
        with col2:
            st.subheader("🎯 Distribución de Actividades")
            
            # Create pie chart for activity distribution
            if 'activity_distribution' in summary_stats:
                import plotly.express as px
                
                fig = px.pie(
                    values=list(summary_stats['activity_distribution'].values()),
                    names=list(summary_stats['activity_distribution'].keys()),
                    title='Distribución de Tipos de Tratamiento'
                )
                
                st.plotly_chart(fig, use_container_width=True)
        
        # Monthly trends for control larvario
        monthly_trends = self.calculations.calculate_monthly_trends(filtered_data)
        
        if not monthly_trends.empty:
            st.subheader("📈 Tendencias Mensuales")
            fig = self.viz_helper.create_monthly_trends_chart(monthly_trends)
            st.plotly_chart(fig, use_container_width=True)
    
    def calculate_treatment_statistics(self, data):
        """Calculate treatment statistics"""
        containers = self.data_processor.get_container_columns()
        
        chemical_treatment = 0
        physical_treatment = 0
        
        for container_type, columns in containers.items():
            for col in columns:
                if col in data.columns:
                    if col.endswith('_TQ'):
                        chemical_treatment += data[col].sum()
                    elif col.endswith('_TF'):
                        physical_treatment += data[col].sum()
        
        return {
            'chemical': int(chemical_treatment),
            'physical': int(physical_treatment)
        }
    
    def calculate_container_type_treatment(self, data):
        """Calculate treatment statistics by container type"""
        containers = self.data_processor.get_container_columns()
        results = []
        
        for container_type, columns in containers.items():
            stats = {'container_type': container_type}
            
            tq_cols = [col for col in columns if col.endswith('_TQ')]
            tf_cols = [col for col in columns if col.endswith('_TF')]
            
            stats['Tratamiento Químico'] = sum(data[col].sum() for col in tq_cols if col in data.columns)
            stats['Tratamiento Físico'] = sum(data[col].sum() for col in tf_cols if col in data.columns)
            
            results.append(stats)
        
        return pd.DataFrame(results)
    
    def calculate_facility_performance(self, data):
        """Calculate performance metrics by facility"""
        if data.empty:
            return pd.DataFrame()
        
        performance_data = []
        
        for facility in data['localidad_eess'].unique():
            facility_data = data[data['localidad_eess'] == facility]
            
            # Get RENIPRESS code
            renipress_code = facility_data['cod_renipress'].iloc[0] if len(facility_data) > 0 else 0
            
            # Calculate metrics
            total_activities = len(facility_data)
            larvicide_used = facility_data['consumo_larvicida'].sum() if 'consumo_larvicida' in facility_data.columns else 0
            containers_treated = self.calculate_treated_containers(facility_data)
            
            # Calculate efficiency rating (0-10 scale)
            efficiency_rating = min(10, (containers_treated / max(1, total_activities)) * 5)
            
            performance_data.append({
                'cod_renipress': renipress_code,
                'localidad_eess': facility,
                'total_activities': total_activities,
                'larvicide_used': larvicide_used,
                'containers_treated': containers_treated,
                'efficiency_rating': efficiency_rating
            })
        
        return pd.DataFrame(performance_data)
    
    def calculate_activity_summary(self, data):
        """Calculate summary statistics for activities"""
        summary = {}
        
        # Basic counts
        summary['Total Registros'] = len(data)
        summary['Establecimientos Únicos'] = data['localidad_eess'].nunique() if 'localidad_eess' in data.columns else 0
        
        # Treatment statistics
        treatment_stats = self.calculate_treatment_statistics(data)
        summary['Tratamiento Químico Total'] = treatment_stats['chemical']
        summary['Tratamiento Físico Total'] = treatment_stats['physical']
        
        # Larvicide consumption
        summary['Consumo Total Larvicida'] = data['consumo_larvicida'].sum() if 'consumo_larvicida' in data.columns else 0
        
        # Activity distribution
        total_treatments = treatment_stats['chemical'] + treatment_stats['physical']
        if total_treatments > 0:
            summary['activity_distribution'] = {
                'Químico': treatment_stats['chemical'],
                'Físico': treatment_stats['physical']
            }
        
        return summary
